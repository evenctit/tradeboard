/*
Navicat MySQL Data Transfer

Source Server         : root
Source Server Version : 50554
Source Host           : localhost:3306
Source Database       : test

Target Server Type    : MYSQL
Target Server Version : 50554
File Encoding         : 65001

Date: 2018-07-30 21:13:45
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for invc_master
-- ----------------------------
DROP TABLE IF EXISTS `invc_master`;
CREATE TABLE `invc_master` (
  `C_MAIN_REF` varchar(40) NOT NULL,
  `AI_NUM` varchar(50) DEFAULT NULL,
  `AI_AMT` decimal(18,0) DEFAULT NULL,
  `INT_AMT` decimal(18,0) DEFAULT NULL,
  `CHARGE_AMT` decimal(18,0) DEFAULT NULL,
  `AI_DT` date DEFAULT NULL,
  `AI_DUE_DT` date DEFAULT NULL,
  `AI_OVD_FEE` decimal(18,0) DEFAULT NULL,
  `AI_SET_DT` date DEFAULT NULL,
  `AI_STAT_BUYER_CD` varchar(2) DEFAULT NULL,
  `AI_STAT_STAFF_CD` varchar(2) DEFAULT NULL,
  `AI_STAT_SUPLR_CD` varchar(2) DEFAULT NULL,
  `AI_UPLD_DT` date DEFAULT NULL,
  `BUYER_ID` varchar(40) DEFAULT NULL,
  `BUYER_NM` varchar(70) DEFAULT NULL,
  `CCY` varchar(3) DEFAULT NULL,
  `IS_FUNDED` varchar(1) DEFAULT NULL,
  `OVD_INT_AMT` decimal(18,0) DEFAULT NULL,
  `OVD_INT_RATE` decimal(9,0) DEFAULT NULL,
  `SUPLR_ID` varchar(40) DEFAULT NULL,
  `SUPLR_NM` varchar(60) DEFAULT NULL,
  `OVD_DT` date DEFAULT NULL,
  `AI_DESC` varchar(80) DEFAULT NULL,
  `GOOD_DESC` varchar(95) DEFAULT NULL,
  PRIMARY KEY (`C_MAIN_REF`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
