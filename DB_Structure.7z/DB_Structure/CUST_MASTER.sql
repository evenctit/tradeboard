/*
Navicat MySQL Data Transfer

Source Server         : root
Source Server Version : 50554
Source Host           : localhost:3306
Source Database       : test

Target Server Type    : MYSQL
Target Server Version : 50554
File Encoding         : 65001

Date: 2018-07-30 21:13:57
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for cust_master
-- ----------------------------
DROP TABLE IF EXISTS `cust_master`;
CREATE TABLE `cust_master` (
  `C_MAIN_REF` varchar(40) CHARACTER SET armscii8 NOT NULL,
  `CUST_NM` varchar(70) DEFAULT NULL,
  `CUST_TYPE` varchar(2) DEFAULT NULL,
  `CUST_ADD` varchar(70) DEFAULT NULL,
  `CUST_ADD2` varchar(70) DEFAULT NULL,
  `CUST_MAIL` varchar(256) DEFAULT NULL,
  `CUST_POST_CD` varchar(15) DEFAULT NULL,
  `CUST_STATE` varchar(3) DEFAULT NULL,
  `CUST_TEL` varchar(30) DEFAULT NULL,
  `C_UNIT_CODE` varchar(12) DEFAULT NULL,
  PRIMARY KEY (`C_MAIN_REF`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
